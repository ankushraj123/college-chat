export interface Confession {
  id: string;
  content: string;
  nickname?: string;
  category: string;
  likes: number;
  dislikes: number;
  comments: Comment[];
  createdAt: Date;
  isApproved: boolean;
  isFeatured?: boolean;
}

export interface Comment {
  id: string;
  content: string;
  nickname?: string;
  likes: number;
  createdAt: Date;
  confessionId: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'stranger';
  timestamp: Date;
}

export interface ChatRoom {
  id: string;
  isActive: boolean;
  messages: ChatMessage[];
  connectedUsers: number;
}

export type SortOption = 'newest' | 'mostLiked' | 'trending';
export type CategoryType = 'all' | 'crush' | 'funny' | 'secrets' | 'complaints' | 'advice';