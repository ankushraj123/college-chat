import React, { useState, useMemo } from 'react';
import { Confession, SortOption, CategoryType, Comment } from '../types';
import { ConfessionCard } from './ConfessionCard';
import { FilterControls } from './FilterControls';
import { FeaturedConfession } from './FeaturedConfession';
import { AdSpace } from './AdSpace';

interface ConfessionFeedProps {
  confessions: Confession[];
  onLike: (id: string) => void;
  onDislike: (id: string) => void;
  onUpdateConfession: (id: string, updates: Partial<Confession>) => void;
}

export function ConfessionFeed({ confessions, onLike, onDislike, onUpdateConfession }: ConfessionFeedProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  const featuredConfession = useMemo(() => {
    return confessions.find(c => c.isFeatured && c.isApproved) || null;
  }, [confessions]);

  const filteredAndSortedConfessions = useMemo(() => {
    let filtered = confessions.filter(c => c.isApproved);
    
    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(c => c.category === selectedCategory);
    }
    
    // Filter by search term
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(c => 
        c.content.toLowerCase().includes(search) ||
        c.nickname?.toLowerCase().includes(search)
      );
    }
    
    // Sort
    switch (sortBy) {
      case 'newest':
        filtered.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        break;
      case 'mostLiked':
        filtered.sort((a, b) => (b.likes - b.dislikes) - (a.likes - a.dislikes));
        break;
      case 'trending':
        filtered.sort((a, b) => {
          const now = new Date();
          const aScore = a.likes + a.comments.length + (now.getTime() - a.createdAt.getTime() < 86400000 ? 50 : 0);
          const bScore = b.likes + b.comments.length + (now.getTime() - b.createdAt.getTime() < 86400000 ? 50 : 0);
          return bScore - aScore;
        });
        break;
    }
    
    return filtered;
  }, [confessions, selectedCategory, searchTerm, sortBy]);

  const handleAddComment = (confessionId: string, content: string, nickname?: string) => {
    const confession = confessions.find(c => c.id === confessionId);
    if (!confession) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      content,
      nickname,
      likes: 0,
      createdAt: new Date(),
      confessionId
    };

    onUpdateConfession(confessionId, {
      comments: [...confession.comments, newComment]
    });
  };

  const handleLikeComment = (confessionId: string, commentId: string) => {
    const confession = confessions.find(c => c.id === confessionId);
    if (!confession) return;

    const updatedComments = confession.comments.map(comment =>
      comment.id === commentId ? { ...comment, likes: comment.likes + 1 } : comment
    );

    onUpdateConfession(confessionId, { comments: updatedComments });
  };

  return (
    <div className="space-y-8">
      {/* Featured Confession */}
      <FeaturedConfession confession={featuredConfession} />

      {/* Banner Ad */}
      <AdSpace size="banner" />

      {/* Filter Controls */}
      <FilterControls
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />

      {/* Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {filteredAndSortedConfessions.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🤷‍♀️</div>
              <p className="text-xl font-medium text-gray-600 dark:text-gray-400 mb-2">
                No confessions found
              </p>
              <p className="text-gray-500 dark:text-gray-500">
                Try adjusting your filters or be the first to share something!
              </p>
            </div>
          ) : (
            <>
              {filteredAndSortedConfessions.map((confession, index) => (
                <React.Fragment key={confession.id}>
                  <ConfessionCard
                    confession={confession}
                    onLike={onLike}
                    onDislike={onDislike}
                    onAddComment={handleAddComment}
                    onLikeComment={handleLikeComment}
                  />
                  {/* Insert ads every 3 posts */}
                  {(index + 1) % 3 === 0 && index < filteredAndSortedConfessions.length - 1 && (
                    <AdSpace size="rectangle" />
                  )}
                </React.Fragment>
              ))}
            </>
          )}
        </div>

        {/* Sidebar */}
        <div className="hidden lg:block space-y-6">
          <AdSpace size="sidebar" />
          
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-purple-100 dark:border-gray-700 p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">📊 Platform Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Confessions</span>
                <span className="font-bold text-purple-600 dark:text-purple-400">{confessions.filter(c => c.isApproved).length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Likes</span>
                <span className="font-bold text-pink-600 dark:text-pink-400">
                  {confessions.reduce((sum, c) => sum + c.likes, 0)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Comments Today</span>
                <span className="font-bold text-orange-600 dark:text-orange-400">
                  {confessions.reduce((sum, c) => sum + c.comments.length, 0)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl p-6 text-white">
            <h3 className="text-lg font-bold mb-2">🎓 Join the Community</h3>
            <p className="text-sm opacity-90 mb-4">
              Share your thoughts anonymously and connect with fellow students
            </p>
            <div className="text-xs opacity-75">
              Safe • Anonymous • Moderated
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}