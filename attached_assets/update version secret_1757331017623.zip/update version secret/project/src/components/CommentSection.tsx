import React, { useState } from 'react';
import { Send, ThumbsUp } from 'lucide-react';
import { Confession } from '../types';

interface CommentSectionProps {
  confession: Confession;
  onAddComment: (confessionId: string, content: string, nickname?: string) => void;
  onLikeComment: (confessionId: string, commentId: string) => void;
}

export function CommentSection({ confession, onAddComment, onLikeComment }: CommentSectionProps) {
  const [commentContent, setCommentContent] = useState('');
  const [commentNickname, setCommentNickname] = useState('');
  const [likedComments, setLikedComments] = useState<Set<string>>(new Set());

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentContent.trim()) return;

    onAddComment(confession.id, commentContent.trim(), commentNickname.trim() || undefined);
    setCommentContent('');
    setCommentNickname('');
  };

  const handleLikeComment = (commentId: string) => {
    if (!likedComments.has(commentId)) {
      setLikedComments(prev => new Set([...prev, commentId]));
      onLikeComment(confession.id, commentId);
    }
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600">
      <div className="space-y-4 mb-4">
        {confession.comments.map((comment) => (
          <div key={comment.id} className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                {comment.nickname && (
                  <span className="text-sm font-medium text-purple-600 dark:text-purple-400">
                    @{comment.nickname}
                  </span>
                )}
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {getTimeAgo(comment.createdAt)}
                </span>
              </div>
              <button
                onClick={() => handleLikeComment(comment.id)}
                className={`flex items-center space-x-1 text-sm transition-all duration-200 ${
                  likedComments.has(comment.id)
                    ? 'text-green-600 dark:text-green-400'
                    : 'text-gray-500 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400'
                }`}
              >
                <ThumbsUp className="w-3 h-3" />
                <span>{comment.likes}</span>
              </button>
            </div>
            <p className="text-gray-700 dark:text-gray-300">{comment.content}</p>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmitComment} className="space-y-3">
        <div className="flex space-x-3">
          <input
            type="text"
            value={commentNickname}
            onChange={(e) => setCommentNickname(e.target.value)}
            placeholder="Nickname (optional)"
            className="flex-1 p-2 rounded-lg border border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 transition-all duration-200 bg-white dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 text-sm"
            maxLength={20}
          />
        </div>
        <div className="flex space-x-3">
          <input
            type="text"
            value={commentContent}
            onChange={(e) => setCommentContent(e.target.value)}
            placeholder="Add an anonymous comment..."
            className="flex-1 p-3 rounded-lg border border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 transition-all duration-200 bg-white dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
            required
          />
          <button
            type="submit"
            disabled={!commentContent.trim()}
            className="px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
}