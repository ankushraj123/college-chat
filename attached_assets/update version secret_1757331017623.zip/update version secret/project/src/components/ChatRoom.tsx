import React, { useState, useEffect, useRef } from 'react';
import { Send, Users, X, MessageSquare } from 'lucide-react';
import { ChatMessage, ChatRoom as ChatRoomType } from '../types';

interface ChatRoomProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatRoom({ isOpen, onClose }: ChatRoomProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleConnect = () => {
    setIsSearching(true);
    // Simulate finding a chat partner
    setTimeout(() => {
      setIsSearching(false);
      setIsConnected(true);
      setMessages([
        {
          id: '1',
          content: "Hey there! 👋 What's up?",
          sender: 'stranger',
          timestamp: new Date()
        }
      ]);
    }, 2000);
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setMessages([]);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMessage.trim() || !isConnected) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      content: currentMessage.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setCurrentMessage('');

    // Simulate stranger response
    if (Math.random() > 0.3) {
      setTimeout(() => {
        const responses = [
          "That's so relatable! 😅",
          "No way, really?",
          "I totally get that feeling",
          "Same here tbh",
          "Haha that's wild",
          "Tell me more about that",
          "I feel you on that one",
          "That's actually pretty cool"
        ];
        
        const strangerMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          content: responses[Math.floor(Math.random() * responses.length)],
          sender: 'stranger',
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, strangerMessage]);
      }, 1000 + Math.random() * 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md h-[600px] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <div className="flex items-center space-x-3">
            <MessageSquare className="w-6 h-6" />
            <div>
              <h3 className="font-bold">Anonymous Chat</h3>
              <p className="text-sm opacity-90">
                {isConnected ? 'Connected • 2 users' : 'Not connected'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/20 transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Connection Status */}
        {!isConnected && (
          <div className="flex-1 flex items-center justify-center p-6">
            {isSearching ? (
              <div className="text-center">
                <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-lg font-medium text-gray-800 dark:text-white mb-2">Finding someone to chat with...</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">This might take a moment</p>
              </div>
            ) : (
              <div className="text-center">
                <Users className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-800 dark:text-white mb-2">Start Anonymous Chat</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                  Connect with a random student for anonymous conversation
                </p>
                <button
                  onClick={handleConnect}
                  className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all duration-200 transform hover:scale-105"
                >
                  Find Chat Partner
                </button>
              </div>
            )}
          </div>
        )}

        {/* Messages */}
        {isConnected && (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs px-4 py-2 rounded-2xl ${
                      message.sender === 'user'
                        ? 'bg-purple-600 text-white rounded-br-md'
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-bl-md'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex space-x-3 items-end">
                <input
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 p-3 rounded-xl border border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 transition-all duration-200 bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                  maxLength={200}
                />
                <button
                  type="submit"
                  disabled={!currentMessage.trim()}
                  className="p-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <div className="flex justify-between items-center mt-2">
                <button
                  type="button"
                  onClick={handleDisconnect}
                  className="text-xs text-red-600 dark:text-red-400 hover:underline"
                >
                  Disconnect
                </button>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {currentMessage.length}/200
                </span>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
}