import React, { useState } from 'react';
import { X, Check, Trash2, Star, AlertTriangle } from 'lucide-react';
import { Confession } from '../types';

interface ModerationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  confessions: Confession[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onDelete: (id: string) => void;
  onToggleFeatured: (id: string) => void;
}

export function ModerationPanel({
  isOpen,
  onClose,
  confessions,
  onApprove,
  onReject,
  onDelete,
  onToggleFeatured
}: ModerationPanelProps) {
  const [activeTab, setActiveTab] = useState<'pending' | 'approved'>('pending');

  const pendingConfessions = confessions.filter(c => !c.isApproved);
  const approvedConfessions = confessions.filter(c => c.isApproved);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-6 h-6 text-orange-600" />
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Moderation Panel</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <X className="w-6 h-6 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setActiveTab('pending')}
            className={`flex-1 px-6 py-3 font-medium transition-colors duration-200 ${
              activeTab === 'pending'
                ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50 dark:bg-orange-900/20'
                : 'text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400'
            }`}
          >
            Pending ({pendingConfessions.length})
          </button>
          <button
            onClick={() => setActiveTab('approved')}
            className={`flex-1 px-6 py-3 font-medium transition-colors duration-200 ${
              activeTab === 'approved'
                ? 'text-green-600 border-b-2 border-green-600 bg-green-50 dark:bg-green-900/20'
                : 'text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400'
            }`}
          >
            Approved ({approvedConfessions.length})
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-96">
          {activeTab === 'pending' ? (
            <div className="space-y-4">
              {pendingConfessions.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No pending confessions</p>
                </div>
              ) : (
                pendingConfessions.map(confession => (
                  <div key={confession.id} className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="px-3 py-1 bg-yellow-200 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200 rounded-full text-sm font-medium">
                          {confession.category}
                        </span>
                        {confession.nickname && (
                          <span className="text-sm text-gray-600 dark:text-gray-400">@{confession.nickname}</span>
                        )}
                      </div>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {confession.createdAt.toLocaleDateString()}
                      </span>
                    </div>
                    
                    <p className="text-gray-800 dark:text-gray-200 mb-4">{confession.content}</p>
                    
                    <div className="flex space-x-3">
                      <button
                        onClick={() => onApprove(confession.id)}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                      >
                        <Check className="w-4 h-4" />
                        <span>Approve</span>
                      </button>
                      <button
                        onClick={() => onReject(confession.id)}
                        className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Reject</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {approvedConfessions.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No approved confessions</p>
                </div>
              ) : (
                approvedConfessions.map(confession => (
                  <div key={confession.id} className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="px-3 py-1 bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-200 rounded-full text-sm font-medium">
                          {confession.category}
                        </span>
                        {confession.nickname && (
                          <span className="text-sm text-gray-600 dark:text-gray-400">@{confession.nickname}</span>
                        )}
                        {confession.isFeatured && (
                          <Star className="w-4 h-4 text-yellow-500" />
                        )}
                      </div>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {confession.createdAt.toLocaleDateString()}
                      </span>
                    </div>
                    
                    <p className="text-gray-800 dark:text-gray-200 mb-4">{confession.content}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {confession.likes - confession.dislikes} points • {confession.comments.length} comments
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => onToggleFeatured(confession.id)}
                          className={`flex items-center space-x-1 px-3 py-1 rounded-lg transition-colors duration-200 ${
                            confession.isFeatured
                              ? 'bg-yellow-200 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200'
                              : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-yellow-200 dark:hover:bg-yellow-800'
                          }`}
                        >
                          <Star className="w-3 h-3" />
                          <span className="text-xs">{confession.isFeatured ? 'Featured' : 'Feature'}</span>
                        </button>
                        <button
                          onClick={() => onDelete(confession.id)}
                          className="flex items-center space-x-1 px-3 py-1 bg-red-200 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-300 dark:hover:bg-red-900/50 transition-colors duration-200"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span className="text-xs">Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}