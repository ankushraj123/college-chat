import React, { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';
import { CategoryType } from '../types';
import { useConfessions } from '../hooks/useConfessions';

interface ConfessionFormProps {
  onSubmit: (confession: {
    content: string;
    nickname?: string;
    category: string;
  }) => void;
}

const categories = [
  { value: 'crush', label: '💕 Crush', color: 'from-pink-500 to-rose-500' },
  { value: 'funny', label: '😂 Funny', color: 'from-yellow-500 to-orange-500' },
  { value: 'secrets', label: '🤫 Secrets', color: 'from-purple-500 to-indigo-500' },
  { value: 'complaints', label: '😤 Complaints', color: 'from-red-500 to-pink-500' },
  { value: 'advice', label: '🤝 Advice', color: 'from-blue-500 to-cyan-500' }
];

export function ConfessionForm({ onSubmit }: ConfessionFormProps) {
  const [content, setContent] = useState('');
  const [nickname, setNickname] = useState('');
  const [category, setCategory] = useState<string>('secrets');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const { canSubmitConfession, getRemainingSubmissions } = useConfessions();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    if (!canSubmitConfession()) {
      setError('You\'ve reached your daily limit of 5 confessions. Try again tomorrow!');
      return;
    }
    setIsSubmitting(true);
    setError('');
    
    // Simulate submission delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    try {
      onSubmit({
        content: content.trim(),
        nickname: nickname.trim() || undefined,
        category
      });

      setContent('');
      setNickname('');
      setCategory('secrets');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit confession');
    }

    setIsSubmitting(false);
  };

  const remainingSubmissions = getRemainingSubmissions();
  const isLimitReached = !canSubmitConfession();
  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-purple-100 dark:border-gray-700 p-6 mb-8">
      <div className="flex items-center space-x-2 mb-4">
        <Sparkles className="w-6 h-6 text-purple-600 dark:text-purple-400" />
        <h2 className="text-xl font-bold text-gray-800 dark:text-white">Share Your Confession</h2>
      </div>
      
      {/* Daily Limit Info */}
      <div className={`mb-4 p-3 rounded-lg ${
        isLimitReached 
          ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800' 
          : 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800'
      }`}>
        <p className={`text-sm font-medium ${
          isLimitReached 
            ? 'text-red-700 dark:text-red-300' 
            : 'text-blue-700 dark:text-blue-300'
        }`}>
          {isLimitReached 
            ? '🚫 Daily limit reached (5/5) - Come back tomorrow!' 
            : `📝 ${remainingSubmissions} confession${remainingSubmissions !== 1 ? 's' : ''} remaining today`
          }
        </p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <p className="text-sm font-medium text-red-700 dark:text-red-300">{error}</p>
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What's on your mind? Share anonymously..."
            className={`w-full p-4 rounded-xl border focus:ring-2 resize-none transition-all duration-200 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 ${
              isLimitReached
                ? 'border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700/50 cursor-not-allowed'
                : 'border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-purple-200 dark:focus:ring-purple-900/30 bg-gray-50 dark:bg-gray-700'
            }`}
            rows={4}
            maxLength={500}
            disabled={isLimitReached}
            required
          />
          <div className="text-right text-sm text-gray-500 dark:text-gray-400 mt-1">
            {content.length}/500
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Nickname (optional)
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="Anonymous Owl"
              className={`w-full p-3 rounded-lg border transition-all duration-200 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 ${
                isLimitReached
                  ? 'border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700/50 cursor-not-allowed'
                  : 'border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 bg-gray-50 dark:bg-gray-700'
              }`}
              maxLength={20}
              disabled={isLimitReached}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={`w-full p-3 rounded-lg border transition-all duration-200 text-gray-800 dark:text-white ${
                isLimitReached
                  ? 'border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700/50 cursor-not-allowed'
                  : 'border-gray-200 dark:border-gray-600 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-200 dark:focus:ring-purple-900/30 bg-gray-50 dark:bg-gray-700'
              }`}
              disabled={isLimitReached}
            >
              {categories.map(cat => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={!content.trim() || isSubmitting || isLimitReached}
          className={`w-full font-semibold py-3 px-6 rounded-xl focus:ring-4 transition-all duration-200 flex items-center justify-center space-x-2 ${
            isLimitReached
              ? 'bg-gray-400 dark:bg-gray-600 text-gray-200 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 focus:ring-purple-200 dark:focus:ring-purple-900/30 disabled:opacity-50 disabled:cursor-not-allowed'
          }`}
        >
          {isSubmitting ? (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Submitting...</span>
            </div>
          ) : isLimitReached ? (
            <span>Daily Limit Reached</span>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Submit Confession</span>
            </>
          )}
        </button>
      </form>
      
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-3 text-center">
        All confessions are anonymous and subject to moderation before appearing publicly. 
        Daily limit: 5 confessions per day to ensure quality content.
      </p>
    </div>
  );
}