import React from 'react';

interface AdSpaceProps {
  size: 'banner' | 'rectangle' | 'sidebar';
  className?: string;
}

export function AdSpace({ size, className = '' }: AdSpaceProps) {
  const dimensions = {
    banner: 'w-full h-24',
    rectangle: 'w-full h-64',
    sidebar: 'w-full h-96'
  };

  const sizeLabels = {
    banner: '728x90',
    rectangle: '300x250',
    sidebar: '160x600'
  };

  return (
    <div className={`${dimensions[size]} ${className} bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 flex flex-col items-center justify-center text-gray-500 dark:text-gray-400 transition-all duration-200 hover:border-purple-400 dark:hover:border-purple-500`}>
      <div className="text-center">
        <p className="text-sm font-medium">Ad Space</p>
        <p className="text-xs mt-1">{sizeLabels[size]} Ready</p>
        <p className="text-xs mt-2 px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full">
          Google AdSense Ready
        </p>
      </div>
    </div>
  );
}