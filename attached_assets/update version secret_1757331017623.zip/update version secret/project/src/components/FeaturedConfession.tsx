import React from 'react';
import { Star, Clock, TrendingUp } from 'lucide-react';
import { Confession } from '../types';

interface FeaturedConfessionProps {
  confession: Confession | null;
}

export function FeaturedConfession({ confession }: FeaturedConfessionProps) {
  if (!confession) return null;

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just posted';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <div className="bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-600 rounded-2xl p-1 mb-8 shadow-xl">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Star className="w-6 h-6 text-yellow-500" />
            <h3 className="text-xl font-bold text-gray-800 dark:text-white">Daily Featured</h3>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1 text-orange-600 dark:text-orange-400">
              <TrendingUp className="w-4 h-4" />
              <span className="font-medium">Trending</span>
            </div>
            <div className="flex items-center space-x-1 text-gray-500 dark:text-gray-400">
              <Clock className="w-4 h-4" />
              <span>{getTimeAgo(confession.createdAt)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2 mb-3">
          <span className="px-3 py-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full text-sm font-medium">
            {confession.category.charAt(0).toUpperCase() + confession.category.slice(1)}
          </span>
          {confession.nickname && (
            <span className="text-sm font-medium text-purple-600 dark:text-purple-400">
              @{confession.nickname}
            </span>
          )}
        </div>

        <p className="text-gray-800 dark:text-gray-200 text-lg leading-relaxed mb-4">
          {confession.content}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm">
            <span className="flex items-center space-x-1 text-green-600 dark:text-green-400 font-medium">
              <span>{confession.likes}</span>
              <span>likes</span>
            </span>
            <span className="flex items-center space-x-1 text-gray-600 dark:text-gray-400">
              <span>{confession.comments.length}</span>
              <span>comments</span>
            </span>
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            🔥 Most popular today
          </div>
        </div>
      </div>
    </div>
  );
}