import React, { useState } from 'react';
import { ThumbsUp, ThumbsDown, MessageCircle, Flag, Star } from 'lucide-react';
import { Confession, Comment } from '../types';
import { CommentSection } from './CommentSection';

interface ConfessionCardProps {
  confession: Confession;
  onLike: (id: string) => void;
  onDislike: (id: string) => void;
  onAddComment: (confessionId: string, content: string, nickname?: string) => void;
  onLikeComment: (confessionId: string, commentId: string) => void;
}

const categoryStyles = {
  crush: 'from-pink-500 to-rose-500',
  funny: 'from-yellow-500 to-orange-500',
  secrets: 'from-purple-500 to-indigo-500',
  complaints: 'from-red-500 to-pink-500',
  advice: 'from-blue-500 to-cyan-500'
};

const categoryEmojis = {
  crush: '💕',
  funny: '😂',
  secrets: '🤫',
  complaints: '😤',
  advice: '🤝'
};

export function ConfessionCard({ confession, onLike, onDislike, onAddComment, onLikeComment }: ConfessionCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);

  const handleLike = () => {
    if (disliked) {
      setDisliked(false);
    }
    if (!liked) {
      setLiked(true);
      onLike(confession.id);
    }
  };

  const handleDislike = () => {
    if (liked) {
      setLiked(false);
    }
    if (!disliked) {
      setDisliked(true);
      onDislike(confession.id);
    }
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      {confession.isFeatured && (
        <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-2">
          <div className="flex items-center justify-center space-x-2 text-white font-medium">
            <Star className="w-4 h-4" />
            <span className="text-sm">Featured Confession</span>
          </div>
        </div>
      )}
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`px-3 py-1 rounded-full bg-gradient-to-r ${categoryStyles[confession.category as keyof typeof categoryStyles]} text-white text-sm font-medium`}>
              {categoryEmojis[confession.category as keyof typeof categoryEmojis]} {confession.category.charAt(0).toUpperCase() + confession.category.slice(1)}
            </div>
            {confession.nickname && (
              <span className="text-sm font-medium text-purple-600 dark:text-purple-400">
                @{confession.nickname}
              </span>
            )}
          </div>
          <button className="text-gray-400 hover:text-red-500 transition-colors duration-200">
            <Flag className="w-4 h-4" />
          </button>
        </div>

        <p className="text-gray-800 dark:text-gray-200 text-lg leading-relaxed mb-4">
          {confession.content}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
          <span>{getTimeAgo(confession.createdAt)}</span>
          <div className="flex items-center space-x-4">
            <span>{confession.likes - confession.dislikes} points</span>
            <span>{confession.comments.length} comments</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleLike}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                liked 
                  ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-green-100 dark:hover:bg-green-900/30 hover:text-green-600 dark:hover:text-green-400'
              }`}
            >
              <ThumbsUp className="w-4 h-4" />
              <span className="font-medium">{confession.likes}</span>
            </button>

            <button
              onClick={handleDislike}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                disliked 
                  ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-red-100 dark:hover:bg-red-900/30 hover:text-red-600 dark:hover:text-red-400'
              }`}
            >
              <ThumbsDown className="w-4 h-4" />
              <span className="font-medium">{confession.dislikes}</span>
            </button>

            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 px-4 py-2 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 hover:bg-purple-200 dark:hover:bg-purple-900/50 transition-all duration-200"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="font-medium">{confession.comments.length}</span>
            </button>
          </div>
        </div>

        {showComments && (
          <CommentSection
            confession={confession}
            onAddComment={onAddComment}
            onLikeComment={onLikeComment}
          />
        )}
      </div>
    </div>
  );
}