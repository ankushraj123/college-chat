import React from 'react';
import { MessageSquare, Plus } from 'lucide-react';

interface FloatingActionButtonProps {
  onChatClick: () => void;
}

export function FloatingActionButton({ onChatClick }: FloatingActionButtonProps) {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col space-y-3">
      {/* Chat Button */}
      <button
        onClick={onChatClick}
        className="w-14 h-14 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-full shadow-lg hover:shadow-xl focus:ring-4 focus:ring-pink-200 dark:focus:ring-pink-900/30 transition-all duration-300 transform hover:scale-110 group"
        title="Anonymous Chat"
      >
        <MessageSquare className="w-6 h-6 mx-auto group-hover:scale-110 transition-transform duration-200" />
      </button>

      {/* Scroll to Top Button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="w-14 h-14 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-full shadow-lg hover:shadow-xl focus:ring-4 focus:ring-purple-200 dark:focus:ring-purple-900/30 transition-all duration-300 transform hover:scale-110 group"
        title="Scroll to Top"
      >
        <Plus className="w-6 h-6 mx-auto rotate-45 group-hover:scale-110 transition-transform duration-200" />
      </button>
    </div>
  );
}