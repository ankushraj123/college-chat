import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ConfessionForm } from './components/ConfessionForm';
import { ConfessionFeed } from './components/ConfessionFeed';
import { ModerationPanel } from './components/ModerationPanel';
import { AdminLogin } from './components/AdminLogin';
import { ChatRoom } from './components/ChatRoom';
import { FloatingActionButton } from './components/FloatingActionButton';
import { ThemeProvider } from './context/ThemeContext';
import { useConfessions } from './hooks/useConfessions';
import { useAuth } from './hooks/useAuth';
import { Confession } from './types';

function AppContent() {
  const {
    confessions,
    loading,
    addConfession,
    updateConfession,
    deleteConfession,
    likeConfession,
    dislikeConfession
  } = useConfessions();

  const { isAdminLoggedIn, login, logout } = useAuth();
  const [showModerationPanel, setShowModerationPanel] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showChatRoom, setShowChatRoom] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handleSubmitConfession = (confessionData: {
    content: string;
    nickname?: string;
    category: string;
  }) => {
    try {
      addConfession(confessionData);
      setShowSuccessMessage(true);
      setTimeout(() => setShowSuccessMessage(false), 3000);
    } catch (error) {
      // Error is handled in the form component
      console.error('Failed to submit confession:', error);
    }
  };

  const handleApproveConfession = (id: string) => {
    updateConfession(id, { isApproved: true });
  };

  const handleRejectConfession = (id: string) => {
    deleteConfession(id);
  };

  const handleToggleFeatured = (id: string) => {
    const confession = confessions.find(c => c.id === id);
    if (confession) {
      // Remove featured status from all other confessions
      confessions.forEach(c => {
        if (c.id !== id && c.isFeatured) {
          updateConfession(c.id, { isFeatured: false });
        }
      });
      // Toggle featured status for this confession
      updateConfession(id, { isFeatured: !confession.isFeatured });
    }
  };

  const handleModerationClick = () => {
    if (isAdminLoggedIn) {
      setShowModerationPanel(true);
    } else {
      setShowAdminLogin(true);
    }
  };

  const handleAdminLogin = (success: boolean) => {
    if (success) {
      login();
      setShowModerationPanel(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-medium text-gray-600 dark:text-gray-400">Loading confessions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-all duration-300">
      <Header onModerationClick={handleModerationClick} />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Success Message */}
        {showSuccessMessage && (
          <div className="fixed top-24 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-xl shadow-lg animate-bounce">
            <p className="font-medium">✨ Confession submitted for review!</p>
          </div>
        )}

        <div className="space-y-8">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent mb-4">
              Share Your Story Anonymously
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              A safe space for college students to share confessions, stories, and connect with peers without judgment
            </p>
          </div>

          <ConfessionForm onSubmit={handleSubmitConfession} />
          
          <ConfessionFeed
            confessions={confessions}
            onLike={likeConfession}
            onDislike={dislikeConfession}
            onUpdateConfession={updateConfession}
          />
        </div>
      </main>

      <FloatingActionButton onChatClick={() => setShowChatRoom(true)} />

      <AdminLogin
        isOpen={showAdminLogin}
        onClose={() => setShowAdminLogin(false)}
        onLogin={handleAdminLogin}
      />

      <ModerationPanel
        isOpen={showModerationPanel}
        onClose={() => {
          setShowModerationPanel(false);
          if (isAdminLoggedIn) {
            logout();
          }
        }}
        confessions={confessions}
        onApprove={handleApproveConfession}
        onReject={handleRejectConfession}
        onDelete={deleteConfession}
        onToggleFeatured={handleToggleFeatured}
      />

      <ChatRoom
        isOpen={showChatRoom}
        onClose={() => setShowChatRoom(false)}
      />

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-16">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Made with 💜 for college students everywhere
            </p>
            <div className="flex justify-center space-x-6 text-sm">
              <button className="text-purple-600 dark:text-purple-400 hover:underline">Privacy Policy</button>
              <button className="text-purple-600 dark:text-purple-400 hover:underline">Community Guidelines</button>
              <button className="text-purple-600 dark:text-purple-400 hover:underline">Contact</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;