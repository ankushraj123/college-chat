import { Confession } from '../types';

export const mockConfessions: Confession[] = [
  {
    id: '1',
    content: "I've had a crush on my study group partner for 3 months but I'm too scared to say anything 😭",
    nickname: "ShyStudier",
    category: 'crush',
    likes: 245,
    dislikes: 12,
    comments: [
      {
        id: 'c1',
        content: "OMG just go for it!! Life's too short",
        nickname: "BoldBae",
        likes: 23,
        createdAt: new Date('2024-12-12T10:30:00'),
        confessionId: '1'
      },
      {
        id: 'c2',
        content: "Maybe drop some hints first? See how they react",
        likes: 18,
        createdAt: new Date('2024-12-12T11:15:00'),
        confessionId: '1'
      }
    ],
    createdAt: new Date('2024-12-12T09:45:00'),
    isApproved: true,
    isFeatured: true
  },
  {
    id: '2',
    content: "My roommate keeps eating my food and I labeled everything but they still don't get it 😤",
    nickname: "HangryStudent",
    category: 'complaints',
    likes: 189,
    dislikes: 8,
    comments: [
      {
        id: 'c3',
        content: "Put some hot sauce on everything, they'll learn 🌶️",
        nickname: "SpicyRevenge",
        likes: 34,
        createdAt: new Date('2024-12-12T08:20:00'),
        confessionId: '2'
      }
    ],
    createdAt: new Date('2024-12-12T08:15:00'),
    isApproved: true
  },
  {
    id: '3',
    content: "I pretended to understand calculus for an entire semester. Still passed somehow 🤡",
    category: 'funny',
    likes: 567,
    dislikes: 23,
    comments: [
      {
        id: 'c4',
        content: "This is literally me in every math class 😂",
        likes: 45,
        createdAt: new Date('2024-12-11T16:45:00'),
        confessionId: '3'
      },
      {
        id: 'c5',
        content: "The real question is how did you pass? 🤔",
        nickname: "MathNerd",
        likes: 28,
        createdAt: new Date('2024-12-11T17:20:00'),
        confessionId: '3'
      }
    ],
    createdAt: new Date('2024-12-11T16:30:00'),
    isApproved: true
  },
  {
    id: '4',
    content: "I think I'm falling for my TA but they're only 2 years older than me. Is this weird?",
    nickname: "ConfusedFreshie",
    category: 'crush',
    likes: 134,
    dislikes: 67,
    comments: [
      {
        id: 'c6',
        content: "As long as they're not grading your work anymore, go for it!",
        likes: 22,
        createdAt: new Date('2024-12-11T14:30:00'),
        confessionId: '4'
      }
    ],
    createdAt: new Date('2024-12-11T14:00:00'),
    isApproved: true
  },
  {
    id: '5',
    content: "I've been wearing the same hoodie for 5 days straight. College is rough y'all 💀",
    nickname: "MessyButBlessed",
    category: 'funny',
    likes: 423,
    dislikes: 15,
    comments: [],
    createdAt: new Date('2024-12-11T12:15:00'),
    isApproved: true
  },
  {
    id: '6',
    content: "Sometimes I go to the library just to cry in the study rooms. Anyone else?",
    category: 'secrets',
    likes: 89,
    dislikes: 5,
    comments: [
      {
        id: 'c7',
        content: "You're not alone 💜 Those study rooms have seen some tears",
        nickname: "GroupTherapy",
        likes: 67,
        createdAt: new Date('2024-12-11T10:45:00'),
        confessionId: '6'
      }
    ],
    createdAt: new Date('2024-12-11T10:30:00'),
    isApproved: true
  }
];