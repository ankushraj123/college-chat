import { useState, useEffect } from 'react';
import { Confession, SortOption, CategoryType } from '../types';
import { mockConfessions } from '../data/mockData';

const DAILY_CONFESSION_LIMIT = 5;

function getTodayKey() {
  return new Date().toDateString();
}

function getDailySubmissionCount(): number {
  const today = getTodayKey();
  const submissions = localStorage.getItem(`submissions_${today}`);
  return submissions ? parseInt(submissions, 10) : 0;
}

function incrementDailySubmissionCount(): void {
  const today = getTodayKey();
  const currentCount = getDailySubmissionCount();
  localStorage.setItem(`submissions_${today}`, (currentCount + 1).toString());
}

export function useConfessions() {
  const [confessions, setConfessions] = useState<Confession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      const savedConfessions = localStorage.getItem('confessions');
      if (savedConfessions) {
        const parsed = JSON.parse(savedConfessions);
        setConfessions(parsed.map((c: any) => ({
          ...c,
          createdAt: new Date(c.createdAt),
          comments: c.comments.map((comment: any) => ({
            ...comment,
            createdAt: new Date(comment.createdAt)
          }))
        })));
      } else {
        setConfessions(mockConfessions);
        localStorage.setItem('confessions', JSON.stringify(mockConfessions));
      }
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const saveConfessions = (newConfessions: Confession[]) => {
    setConfessions(newConfessions);
    localStorage.setItem('confessions', JSON.stringify(newConfessions));
  };

  const canSubmitConfession = (): boolean => {
    return getDailySubmissionCount() < DAILY_CONFESSION_LIMIT;
  };

  const getRemainingSubmissions = (): number => {
    return Math.max(0, DAILY_CONFESSION_LIMIT - getDailySubmissionCount());
  };
  const addConfession = (confession: Omit<Confession, 'id' | 'likes' | 'dislikes' | 'comments' | 'createdAt' | 'isApproved'>) => {
    if (!canSubmitConfession()) {
      throw new Error('Daily confession limit reached. Try again tomorrow!');
    }

    const newConfession: Confession = {
      ...confession,
      id: Date.now().toString(),
      likes: 0,
      dislikes: 0,
      comments: [],
      createdAt: new Date(),
      isApproved: false
    };
    
    incrementDailySubmissionCount();
    const updated = [newConfession, ...confessions];
    saveConfessions(updated);
    return newConfession;
  };

  const updateConfession = (id: string, updates: Partial<Confession>) => {
    const updated = confessions.map(c => 
      c.id === id ? { ...c, ...updates } : c
    );
    saveConfessions(updated);
  };

  const deleteConfession = (id: string) => {
    const updated = confessions.filter(c => c.id !== id);
    saveConfessions(updated);
  };

  const likeConfession = (id: string) => {
    updateConfession(id, { 
      likes: confessions.find(c => c.id === id)!.likes + 1 
    });
  };

  const dislikeConfession = (id: string) => {
    updateConfession(id, { 
      dislikes: confessions.find(c => c.id === id)!.dislikes + 1 
    });
  };

  const sortConfessions = (confessions: Confession[], sortBy: SortOption): Confession[] => {
    switch (sortBy) {
      case 'newest':
        return [...confessions].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      case 'mostLiked':
        return [...confessions].sort((a, b) => (b.likes - b.dislikes) - (a.likes - a.dislikes));
      case 'trending':
        // Simple trending algorithm: likes + comments in last 24 hours
        return [...confessions].sort((a, b) => {
          const now = new Date();
          const aScore = a.likes + a.comments.length + (now.getTime() - a.createdAt.getTime() < 86400000 ? 50 : 0);
          const bScore = b.likes + b.comments.length + (now.getTime() - b.createdAt.getTime() < 86400000 ? 50 : 0);
          return bScore - aScore;
        });
      default:
        return confessions;
    }
  };

  const filterConfessions = (confessions: Confession[], category: CategoryType, searchTerm: string): Confession[] => {
    let filtered = confessions.filter(c => c.isApproved);
    
    if (category !== 'all') {
      filtered = filtered.filter(c => c.category === category);
    }
    
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(c => 
        c.content.toLowerCase().includes(search) ||
        c.nickname?.toLowerCase().includes(search)
      );
    }
    
    return filtered;
  };

  return {
    confessions,
    loading,
    addConfession,
    updateConfession,
    deleteConfession,
    likeConfession,
    dislikeConfession,
    sortConfessions,
    filterConfessions,
    canSubmitConfession,
    getRemainingSubmissions
  };
}