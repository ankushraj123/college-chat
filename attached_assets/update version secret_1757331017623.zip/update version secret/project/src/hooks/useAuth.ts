import { useState, useEffect } from 'react';

const SESSION_DURATION = 2 * 60 * 60 * 1000; // 2 hours in milliseconds

export function useAuth() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  useEffect(() => {
    checkAdminSession();
  }, []);

  const checkAdminSession = () => {
    const adminLoggedIn = localStorage.getItem('adminLoggedIn');
    const loginTime = localStorage.getItem('adminLoginTime');

    if (adminLoggedIn === 'true' && loginTime) {
      const currentTime = Date.now();
      const sessionAge = currentTime - parseInt(loginTime);

      if (sessionAge < SESSION_DURATION) {
        setIsAdminLoggedIn(true);
      } else {
        // Session expired
        logout();
      }
    }
  };

  const login = () => {
    setIsAdminLoggedIn(true);
  };

  const logout = () => {
    localStorage.removeItem('adminLoggedIn');
    localStorage.removeItem('adminLoginTime');
    setIsAdminLoggedIn(false);
  };

  return {
    isAdminLoggedIn,
    login,
    logout,
    checkAdminSession
  };
}